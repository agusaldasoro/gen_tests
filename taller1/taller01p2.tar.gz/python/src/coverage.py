'''
Abstract class that represents an object
to report the coverage of statements or branches
'''
class Coverage:

    '''
    Constructor, module_name is the 
    module to read lines and branches from
    '''
    def __init__(self, module_name=None):
        pass

    '''
    Set-up coverage before running any tests
    '''
    def setUp(self):
        pass
    
    '''
    Tear-down all tracing configuration
    '''
    def tearDown(self):
        pass

    '''
    Returns a float between 0 and 1 representing 
    the obtained coverage during test execution
    '''
    def get_coverage(self):
        pass
    
    '''
    Override this method to customize the 
    final message to the user
    '''
    def printCoverage(self):
        pass
    
'''
Reports the statement Coverage
'''
class LineCoverage(Coverage):
    
    def printCoverage(self):
        print("Line Coverage is " + str(self.get_coverage()) + "%")

'''
Reports the branch Coverage
'''
class BranchCoverage(Coverage):
    
    def printCoverage(self):
        print("Branch Coverage is " + str(self.get_coverage())+ "%")
