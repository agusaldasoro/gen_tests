'''
Created on Aug 10, 2016

@author: galeotti
'''
import unittest
import cgi_decode
import coverage 

class TestCGIDecode(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        cls.c = coverage.LineCoverage("cgi_decode")	
        #cls.c = coverage.BranchCoverage("cgi_decode")
        cls.c.setUp()


    def test0(self):
        pass
    
    def test1(self):
        decoded_str = cgi_decode.cgi_decode("test")
        self.assertEquals(decoded_str, "test")
 
    @unittest.expectedFailure
    def test2(self):
        cgi_decode.cgi_decode("+%0d+%4j")
 
    def test3(self):
        decoded_str = cgi_decode.cgi_decode("abc")
        self.assertEquals(decoded_str,"abc")
    
    @classmethod
    def tearDownClass(cls):
        cls.c.tearDown()
        cls.c.printCoverage()

